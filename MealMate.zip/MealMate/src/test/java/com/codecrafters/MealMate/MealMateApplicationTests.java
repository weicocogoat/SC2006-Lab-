package com.codecrafters.MealMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
