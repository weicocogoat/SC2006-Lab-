package com.codecrafters.MealMate.enums;

public enum UserState{
    LoggedIn,
    LoggedOut
}