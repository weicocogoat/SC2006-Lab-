package com.codecrafters.MealMate.enums;

public enum MealType{
    Breakfast,
    Lunch,
    Dinner,
    Dessert
}