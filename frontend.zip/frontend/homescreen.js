if (window.location.pathname === "/") {
    document.getElementById("home").classList.add("active");
}
