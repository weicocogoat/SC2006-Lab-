document.addEventListener('DOMContentLoaded', function() {

    document.querySelector('#home_button').onclick = function() {
        window.location.href="homescreen(signed in).html";
    }

});