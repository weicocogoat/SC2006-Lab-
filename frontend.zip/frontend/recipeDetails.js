document.addEventListener('DOMContentLoaded', function () {

    // Get the "Add to Meal" link and the modal
    var addToMealButton = document.getElementById("addToMeal");
    var addToMealModal = document.getElementById("addToMealModal");

    // When the link is clicked, show the modal
    addToMealButton.addEventListener("click", function (event) {
        event.preventDefault();
        addToMealModal.style.display = "block";
    });

    // When the user clicks anywhere outside of the modal, close it
    window.addEventListener("click", function (event) {
        if (event.target == addToMealModal) {
            addToMealModal.style.display = "none";
        }
    })
});
